package com.hostal.hostal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostalApplicationTests {

	@Test
	void contextLoads() {
	}

}
